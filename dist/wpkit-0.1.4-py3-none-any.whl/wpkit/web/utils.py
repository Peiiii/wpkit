from wpkit import piu
from wpkit import pkg_info
from wpkit.basic import join_path,IterObject,SecureDirPath,PointDict,Path
from wpkit.basic import render_template as render