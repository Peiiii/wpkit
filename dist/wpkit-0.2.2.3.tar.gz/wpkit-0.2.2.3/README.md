# wpkit
### *StartLogging*


`0.2.1.6`:
```
Add to wpkit.piu: 
    class Table:
        A db that stored data as record object. 
    class FileStorageHelper(Piu):
        A Piu db binded to a Table db , that helps handle files. 
```

`0.2.1.2`:
```
Add to wpkit:
    cv: 
        class Helper}
Add to wpkit.piu: 
    class FileDict:
        A dict binded to a file with specific name. 
    class BackupDB:
        A db stores old values even when keys are updated. 
```