#!python -e

import os,glob,shutil
from wpkit.run import cli
import fire

fire.Fire(cli)



