import os,shutil,glob
from wpkit.fsutil.utils import *
import fire

cmpd=compare_dirs
if __name__ == '__main__':
    fire.Fire()



