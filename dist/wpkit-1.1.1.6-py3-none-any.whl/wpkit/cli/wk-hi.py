#!python3

print('*'*100)
print('Hi , welcome to be a use of wpkit!'.center(100,'*'))
print('*'*100)