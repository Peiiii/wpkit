from wpkit.run import cli
import fire

def main():
    fire.Fire(cli)

# fire.Fire(cli)
# main()