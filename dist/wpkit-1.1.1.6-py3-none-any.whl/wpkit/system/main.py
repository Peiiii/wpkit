import os

user_home=os.path.expanduser('~')