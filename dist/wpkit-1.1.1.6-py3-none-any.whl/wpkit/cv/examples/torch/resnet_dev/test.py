import numpy as np

a=np.array([])

