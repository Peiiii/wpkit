
from wpkit.web.applications.demo import demo as demoapp
from wpkit.projects.setup import setup_default
from wpkit.install import install_requirements as install

if __name__ == '__main__':
    import fire
    fire.Fire()