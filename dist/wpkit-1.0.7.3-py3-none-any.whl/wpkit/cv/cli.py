import fire
from .utils import *
tfd=test_font_dir

if __name__ == '__main__':
    fire.Fire()