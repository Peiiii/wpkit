from .rar import *
import fire
if __name__ == '__main__':
    fire.Fire()