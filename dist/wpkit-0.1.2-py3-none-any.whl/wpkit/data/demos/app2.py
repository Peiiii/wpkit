import wpkit
wpkit.web.start_simple_http_server(__name__,host='127.0.0.1',port=80)