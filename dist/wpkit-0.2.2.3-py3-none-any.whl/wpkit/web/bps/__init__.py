
from .pan import BluePan
from .static import BlueStatic
from .board import BlueBoard
from .sitemap import BlueSitemap
from .welcome import BlueWelcomePage
from .myblueprint import *
from .post_and_download import BluePostAndDownload